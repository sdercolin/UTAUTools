oto2ust
To simply generate a ust file which contains all notes in your oto.

Feel free to contact me if you have any question or advice about it.
Email: sdercolin@outlook.jp

sdercolin
2015.2.17
